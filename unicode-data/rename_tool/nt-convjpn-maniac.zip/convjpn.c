#define	UNICODE
#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#define	DEFAULT_LOG_ENV	"USERPROFILE"
#define	DEFAULT_LOG_DIR	"C:"

static HANDLE out;

extern WCHAR map[2][65536];

enum { OLDCHINESETOUNICODE, UNICODETOOLDCHINESE };

static int convert_way = 0;
static int applytoall = 0;
static int recursive = 0;
static FILE *fp;

static void usage(char *program)
{
  printf("Usage:\n"
      "%s [-a] [-y] [-r] [-u|-o] directory1 [directory2 ...]\n"
      "    -a     auto porcess all directories in all HDD\n"
      "    -y     yes to all renaming process\n"
      "    -u     mapping old chinese filename to unicode filename(default)\n"
      "    -r     rename directories recursively\n"
      "    -o     mapping unicode filename to old chinese filename\n", program);
  exit(0);
}

int renamedirectory()
{
  WIN32_FIND_DATA FindFileData;
  HANDLE hFind;
  TCHAR currdir[MAX_PATH];
  TCHAR newname[MAX_PATH];
  DWORD unused, dirlength;
  char buf[128];

  dirlength = GetCurrentDirectory(MAX_PATH, currdir);
  newname[0] = '*';
  newname[1] = 0;

  hFind = FindFirstFile(newname, &FindFileData);
  while(hFind != INVALID_HANDLE_VALUE) {
    if((FindFileData.cFileName[0] == '.' && 
	(FindFileData.cFileName[1] == '.' && FindFileData.cFileName[2] == 0 ||
	 FindFileData.cFileName[1] == 0)))
      if(!FindNextFile(hFind, &FindFileData)) {
       	FindClose(hFind);
	break;
      } else
	continue;

    if(recursive && (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
      SetCurrentDirectory(FindFileData.cFileName);
      renamedirectory();
      SetCurrentDirectory(currdir);
    }

    do {
      register unsigned long *change = 0;
      DWORD fnlength;

      {
	register TCHAR *p = newname;
	register TCHAR *q = FindFileData.cFileName;
	register TCHAR c;
	register unsigned short *r;

	while(c = *q++) {
	  if(map[convert_way][c]) {
	    change++;
	    *p++ = map[convert_way][c];
	  } else
	    *p++ = c;
	}
	*p = 0;
	fnlength = (int) (p - newname);
      }

      if(!change)
	break;

      {
        { static WCHAR string[] = { 0x76ee, 0x9304, 0x003a, 0x0020};
          WriteConsoleW(out, string, 4, &unused, NULL);
	  if(fp) fwrite(string, sizeof(string), 1, fp);
	}
	WriteConsoleW(out, currdir, dirlength, &unused, NULL);
	if(fp) fwrite(currdir, dirlength * sizeof(WCHAR), 1, fp);
        { static WCHAR string[] = { 0xd, 0xa, 0x4f86, 0x6e90, 0x003a, 0x0020};
          WriteConsoleW(out, string, 6, &unused, NULL);
	  if(fp) fwrite(string, sizeof(string), 1, fp);
	}
	WriteConsoleW(out, FindFileData.cFileName, fnlength, &unused, NULL);
	if(fp) fwrite(FindFileData.cFileName, fnlength * sizeof(WCHAR), 1, fp);
        { static WCHAR string[] = { 0xd, 0xa, 0x76ee, 0x6a19, 0x003a, 0x20};
          WriteConsoleW(out, string, 6, &unused, NULL);
	  if(fp) fwrite(string, sizeof(string), 1, fp);
	}
	WriteConsoleW(out, newname, fnlength, &unused, NULL);
	if(fp) fwrite(newname, fnlength * sizeof(WCHAR), 1, fp);
	if(!applytoall) 
	{ static WCHAR string[] = { 0xd, 0xa, 0x8acb, 0x554f, 0x8981, 0x8f49, 0x63db, 0x55ce,
    	    0x003f, 0x0020, 0x0028, 0x0079, 0x002f, 0x004e, 0x0029, 0x0020, 0x000d,
	    0x000a}; WriteConsoleW(out, string, 18, &unused, NULL);
	  if(fp) fwrite(string, sizeof(string), 1, fp);
	}
	else {
	  static WCHAR string[] = { 0xd, 0xa };
	  WriteConsoleW(out, string, 2, &unused, NULL);
	  if(fp) fwrite(string, sizeof(string), 1, fp);
	}
      }

      if(applytoall || 
	  fgets(buf, sizeof(buf), stdin) && (buf[0] == 'y' || buf[0] == 'Y')) {
	if(!applytoall) {
	  static WCHAR string[] = { 0x0043, 0x006f, 0x006e, 0x0076, 0x0065,
	    0x0072, 0x0074, 0x0065, 0x0064, 0x000d, 0x000a};
	  if(fp) fwrite(string, sizeof(string), 1, fp);
	}
	MoveFile(FindFileData.cFileName, newname);
      }

      if(fp) fflush(fp);
    } while(0);

    if(!FindNextFile(hFind, &FindFileData)) {
      FindClose(hFind);
      break;
    }
  }
}

WCHAR *allFixedHD()
{
  static WCHAR buf[1024];
  WCHAR *p = buf;
  DWORD driver = GetLogicalDrives();
  int i;
  static char dir[4] = {0, ':', '\\', 0};

  for(i = 0; i < 26; i++) {
    if(driver & (1 << i)) {
      dir[0] = 'A' + i;
      if(GetDriveTypeA(dir) == DRIVE_FIXED) {
	*p++ = ' ';
	*p++ = dir[0];
	*p++ = ':';
	*p++ = '\\';
      }
    }
  }
  *p = 0;
  return buf + 1;
}

int main(int argc, char *argv[])
{
  TCHAR currdir[MAX_PATH];
  WCHAR *commandline, c;
  int abort = 0;
  char logfilename[1024];

  out = GetStdHandle(STD_OUTPUT_HANDLE);
  commandline = GetCommandLineW();

  while((c = *commandline++) && c != ' ' && c != '\t') ;
  if(!c)
    usage(argv[0]);
  while((c = *commandline++) && (c == ' ' || c == '\t')) ;
  if(!c)
    usage(argv[0]);
  commandline--;


  while((c = *commandline) && !abort) {
    if(c == '-') {
      if(*(++commandline) == '-') {
	while((c = *++commandline) && c != ' ' && c != '\t') ;
	break;
      }

      while(c = *commandline++) {
	if(c == 'y' || c == 'Y')
	  applytoall = 1;
	else if(c == 'u' || c == 'U')
	  convert_way = OLDCHINESETOUNICODE;
	else if(c == 'o' || c == 'O')
	  convert_way = UNICODETOOLDCHINESE;
	else if(c == 'r' || c == 'R')
	  recursive = 1;
	else if(c == 'h' || c == 'H') {
	  usage(argv[0]);
	  exit(0);
	} else if(c == 'a' || c == 'A') {
	  applytoall = 1;
	  recursive = 1;
	  commandline = allFixedHD();
	  abort = 1;
	  break;
	} else if(c == ' ')
	  break;
      }
    } else {
      break;
    }
  }

  GetCurrentDirectory(MAX_PATH, currdir);
  {
    struct tm *now;
    time_t tmp;
    char *tmpdir = getenv(DEFAULT_LOG_ENV);
    struct stat sb;

    time(&tmp);
    now = localtime(&tmp);
    if(!tmpdir)
      tmpdir = getenv("TEMP");

    if(!tmpdir)
      tmpdir = DEFAULT_LOG_DIR;
    sprintf(logfilename, "%s\\convjpn-logs", tmpdir);
    if(stat(logfilename, &sb))
      mkdir(logfilename, 0666);

    sprintf(logfilename, "%s\\convjpn-logs\\%04d%02d%02d-%02d%02d%02d.log", 
	tmpdir,
	now->tm_year + 1900, now->tm_mon + 1, now->tm_mday,
	now->tm_hour, now->tm_min, now->tm_sec);
  }

  fp = fopen(logfilename, "wb");
  if(fp) {
    static const WCHAR tmp = 0xfeff;
    fwrite(&tmp, sizeof(tmp), 1, fp);
  }

  while(c = *commandline) {
    WCHAR newdir[MAX_PATH + MAX_PATH], *p;
    while(c && (c == ' ' || c == '\t')) c = *++commandline;

    if(c == '"') {
      p = newdir;
      while((c = *++commandline) && c != '"')
	*p++ = c;
      *p++ = 0;
    } else {
      p = newdir;
      while((c = *commandline++) && c != ' ' && c != '\t')
	*p++ = c;
      *p++ = 0;
    }
    commandline++;
    SetCurrentDirectory(newdir);
    renamedirectory();
  }

  if(fp) {
    fclose(fp);
  }
  SetCurrentDirectory(currdir);
}
