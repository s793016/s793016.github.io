#!/usr/bin/perl

while(<>) {
  chomp;
  ($f, $t) = split(/\s+/);

  #$f =~ s/(..)(..)/$2$1/;
  #$t =~ s/(..)(..)/$2$1/;

  $a[hex($f)] = hex($t) if hex($f) >= 0x100;
  $b[hex($t)] = hex($f) if hex($t) >= 0x100;
}

print "#include<windows.h>\nWCHAR map[2][65536] = {\n";
for (0 .. 65535) {
  print $_ == 0? "   {": sprintf(" /* 0x%04x */\n    ", $_) unless $_ & 0x7;
  printf "0x%04x%s", $a[$_], ($_ != 65535)? ", ": "";
}
print "\n}," ;

for (0 .. 65535) {
  print $_ == 0? " {": sprintf(" /* 0x%04x */\n    ", $_) unless $_ & 0x7;
  printf "0x%04x%s", $b[$_], ($_ != 65535)? ", ": "";
}
print "\n}\n};" 
